# Copyright (c) 2017, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt


from frappe.tests.utils import FrappeTestCase


class TestCourseSchedulingTool(FrappeTestCase):
	pass
