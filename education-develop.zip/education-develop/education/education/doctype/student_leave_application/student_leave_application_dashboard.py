def get_data():
	return {
		"fieldname": "leave_application",
		"transactions": [{"items": ["Student Attendance"]}],
	}
