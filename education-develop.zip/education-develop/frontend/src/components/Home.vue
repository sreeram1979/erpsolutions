<template lang="">
  <div>Home</div>
</template>
<script setup></script>
