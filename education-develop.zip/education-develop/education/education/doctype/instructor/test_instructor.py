# Copyright (c) 2015, Frappe Technologies and Contributors
# See license.txt


from frappe.tests.utils import FrappeTestCase

# test_records = frappe.get_test_records('Instructor')


class TestInstructor(FrappeTestCase):
	pass
