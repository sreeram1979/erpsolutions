# Copyright (c) 2015, Frappe Technologies and contributors
# For license information, please see license.txt


from frappe.model.document import Document


class StudentGroupStudent(Document):
	pass
