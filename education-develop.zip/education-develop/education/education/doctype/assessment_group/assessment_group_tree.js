frappe.treeview_settings['Assessment Group'] = {}
