# Copyright (c) 2018, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt


from frappe.tests.utils import FrappeTestCase


class TestQuestion(FrappeTestCase):
	pass
