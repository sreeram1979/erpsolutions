frappe.listview_settings['Fee Schedule'] = {
  add_fields: ['status', 'due_date', 'grand_total'],
}
