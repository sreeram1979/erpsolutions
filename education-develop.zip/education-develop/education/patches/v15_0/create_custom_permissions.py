from education.install import create_permissions, get_permissions


def execute():
	create_permissions(get_permissions())
