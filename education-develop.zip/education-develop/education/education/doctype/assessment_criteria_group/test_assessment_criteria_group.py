# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt


from frappe.tests.utils import FrappeTestCase

# test_records = frappe.get_test_records('Assessment Criteria Group')


class TestAssessmentCriteriaGroup(FrappeTestCase):
	pass
