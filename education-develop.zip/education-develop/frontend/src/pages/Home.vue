<template>
  <div class="h-min-[500px]">
    <Calendar />
  </div>
</template>

<script setup>
import Calendar from '../components/Calendar.vue'
</script>
