<template>
  <div>Leaves</div>
</template>

<script setup>
import { onMounted } from 'vue'
</script>
