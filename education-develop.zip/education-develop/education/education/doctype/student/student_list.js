frappe.listview_settings['Student'] = {
  add_fields: ['image'],
}
