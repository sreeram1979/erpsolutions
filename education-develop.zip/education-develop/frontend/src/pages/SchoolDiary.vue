<template lang="">
  <div>Diary</div>
</template>

<script setup></script>

<style></style>
